# Alibaba RFQ Scraper (Python + Selenium)

This project scrapes RFQ (Request for Quotation) listings from [Alibaba](https://sourcing.alibaba.com/rfq/rfq_search_list.htm?country=AE&recently=Y), specifically for the United Arab Emirates, and exports the data into a structured CSV file.

## 📌 Features
- ✅ Automated browsing with Selenium (headless Chrome)
- ✅ Handles dynamic, JavaScript-loaded content
- ✅ Extracts key fields: Title, Buyer, Country, Quantity, Quotes Left
- ✅ Saves to clean, tabular CSV
- ✅ Submission-ready for assignments or internships

## 🛠️ Technologies Used
- Python 3.x
- Selenium WebDriver
- CSV module

## 🚀 How to Run
1. Install dependencies:
   ```
   pip install selenium
   ```
2. Make sure [ChromeDriver](https://sites.google.com/chromium.org/driver/) is installed and in your PATH
3. Run the script:
   ```
   python alibaba_rfq_scraper.py
   ```
4. Output will be saved in `alibaba_rfq_data.csv`

## 🧑‍💻 Author
Your Name

## 📄 License
MIT
